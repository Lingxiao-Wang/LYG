check_treatment <- function(x, cox_t.d1, cox_t.d2, nm="treatment") {

  len <- length(x)
  if (!len) {
    if (!length(cox_t.d1) && !length(cox_t.d2)) {
      msg <- paste0("ERROR: if ", nm, " is NULL, then fit.trial and fit2.trial cannot both be NULL") 
      stop(msg)
    } 
    return(NULL)
  }
  msg <- paste0("ERROR: ", nm,  " must be a numeric vector of length 2",
                " for the effects of the treatment (i.e., log-HR) on the",
                " major event of interest and on the competing event.")

  if (is.numeric(x)) {
    if (!is.vector(x)) stop(msg)
    if (len != 2) stop(msg)
    if (any(!is.finite(x))) {
      stop(paste0("ERROR: ", nm, " contains non-finite values"))
    }
  } else {
    stop(msg)
  }
  NULL
}

check_fit <- function(x, name, which=0) {

  if (!which) {
    cls <- c("svycoxph", "coxph")
  } else if (which == 1) {
    cls <- "svycoxph"
  } else {
    cls <- "coxph"
  }
  clsx <- class(x)
  tmp  <- clsx %in% cls
  if (!any(tmp)) {
    str <- paste0("'", cls, "'")
    str <- paste0(str, collapse=" or ")
    msg <- paste0("ERROR: ", name, " must have class ", str)
    stop(msg)
  }
  # Check coefficents
  coef <- x[["coefficients", exact=TRUE]]
  if (!length(coef)) {
    stop(paste0("ERROR: coefficients not found in ", name))
  }
  if (any(!is.finite(coef))) {
    stop(paste0("ERROR: non-finite coefficients found in ", name))
  }

  # For coxph object, check that the data still exists in evironment
  if (!("svycoxph" %in% clsx)) {
    dat <- x$call$data
    if (is.null(dat)) {
      msg <- paste0("ERROR: for the coxph object '", name,
                    "', a data frame to fit the model must exist in memory.")
      stop(msg) 
    }
    dat <- as.character(dat)
    if (!exists(dat)) {
      msg <- paste0("ERROR: for the coxph object '", name, "', the data '",
                    dat, "' must still exist in memory.")
      stop(msg) 
    }
  }

  NULL
}

check_num <- function(x, name, len=0, pos=1) {

  xlen <- length(x)
  if (!len && !xlen) return(NULL)
  if (len && (xlen != len)) {
    stop(paste0("ERROR: ", name, " must be a numeric value"))
  }
  if (!is.finite(x)) stop(paste0("ERROR: ", name, " must be a numeric value"))
  if (pos && (x <= 0)) {
    stop(paste0("ERROR: ", name, " must be a positive value"))
  }
  NULL
}

check_log <- function(x, name) {

  if (length(x) != 1) stop(paste0("ERROR: ", name, " must be TRUE or FALSE"))
  tmp <- x %in% c(TRUE, FALSE)
  if (!tmp) stop(paste0("ERROR: ", name, " must be TRUE or FALSE"))
  NULL
}

check_x0 <- function(x0, fit, fit2, trt, name="x0") {

  if (!length(x0)) {
    # Merge model matrices together
    x0  <- model.matrix(fit)
    x02 <- model.matrix(fit2)
    if (nrow(x0) != nrow(x02)) {
      stop("ERROR: Model matrices for fit.survey and fit2.survey have different numbers of rows")
    }
    rnms  <- rownames(x0)
    rnms2 <- rownames(x02)
    flag  <- length(rnms)
    flag2 <- length(rnms2)
    if (flag + flag2 == 1) {
      stop("ERROR: Model matrices for fit.survey and fit2.survey have different row names")
    }
    if (flag && flag2) {
      rows <- match(rnms, rnms2)
      if (any(is.na(rows))) {
        stop("ERROR: Model matrices for fit.survey and fit2.survey have different row names")
      }
      x02 <- x02[rows, , drop=FALSE] 
    }
    # Get columns in x02 not in x0
    cx  <- colnames(x0)
    cx2 <- colnames(x02)
    tmp <- !(cx2 %in% cx)
    cx2 <- cx2[tmp]
    if (length(cx2)) x0 <- cbind(x0, x02[, cx2, drop=FALSE]) 
  }

  if (!is.matrix(x0) && !is.data.frame(x0)) {
    stop(paste0("ERROR: ", name, " must be a matrix or data frame"))
  }
  coef  <- fit$coefficients
  coef2 <- fit2$coefficients
  vars  <- unique(c(names(coef), names(coef2)))
  # Remove treatment variable if known
  if (isString(trt)) vars <- vars[!(vars %in% trt)]
  if (!length(vars)) {
    stop("ERROR: treatment is the only predictor in fit.survey and fit2.survey")
  }

  tmp  <- !(vars %in% colnames(x0))
  if (any(tmp)) {
    miss <- paste0("'", vars[tmp], "'")
    miss <- paste0(miss, collapse=", ")
    msg  <- paste0("ERROR: ", name, " is missing columns ", miss)
    stop(msg)
  }
  x0 <- x0[, vars, drop=FALSE]
  x0 <- try(as.matrix(x0), silent=FALSE)
  if ("try-error" %in% class(x0)) {
    stop(paste0("ERROR: ", name, " cannot be coerced to a matrix"))
  }

  x0
}

check_fits.survey <- function(fit1, fit2) {

  nm1   <- "coxfit.survey"
  nm2   <- "coxfit2.survey"
  vars1 <- names(fit1$coeff)
  vars2 <- names(fit2$coeff)
  flag  <- all.equal(vars1, vars2)
  if (!is.logical(flag)) flag <- FALSE
  if (!flag) {
    msg <- paste0("ERROR: coefficients differ in ", nm1, " and ", nm2)
    stop(msg)
  }
  NULL
}

check_fits.trial <- function(fit1, fit2) {

  if (!length(fit1) && !length(fit2)) return(NULL)

  nm1   <- "coxfit.trial"
  nm2   <- "coxfit2.trial"

  # fits should only have treatment variable as a covariate
  coef1 <- fit1$coefficients
  if (length(coef1) != 1) {
    msg <- paste0("ERROR: ", nm1, " must only be fit with a binary treatment variable (one covariate)")
    stop(msg)
  }

  if (!length(fit2)) return(NULL)
  coef2 <- fit2$coefficients
  if (length(coef2) != 1) {
    msg <- paste0("ERROR: ", nm2, " must only be fit with a binary treatment variable (one covariate)")
    stop(msg)
  }

  vars1 <- names(coef1)
  vars2 <- names(coef2)
  flag  <- all.equal(vars1, vars2)
  if (!is.logical(flag)) flag <- FALSE
  if (!flag) {
    msg <- paste0("ERROR: coefficients differ in ", nm1, " and ", nm2)
    stop(msg)
  }
  NULL
}

isString <- function(x) {
  ((length(x) == 1) && is.character(x))
}