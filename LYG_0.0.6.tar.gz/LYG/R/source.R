lyg <- function(fit.survey, fit2.survey, fit.trial=NULL, fit2.trial=NULL,
                time.eff.end=NULL, time.cutoff=NULL, treatment=NULL,
                x0=NULL, calc.var=FALSE, save.memory=FALSE) {

  # Check for errors
  check_fit(fit.survey, "fit.survey")
  check_fit(fit2.survey, "fit2.survey")
  if (length(fit.trial)) check_fit(fit.trial, "fit.trial")
  if (length(fit2.trial)) check_fit(fit2.trial, "fit2.trial")
  check_fits.trial(fit.trial, fit2.trial)
  check_treatment(treatment, fit.trial, fit2.trial)
  check_num(time.eff.end, "time.eff.end")
  check_num(time.cutoff, "time.cutoff")
  check_log(calc.var, "calc.var")
  x0  <- check_x0(x0, fit.survey, fit2.survey, treatment)
  obj <- list(time.eff.end=time.eff.end, time.cutoff=time.cutoff,
              calc.var=calc.var, save.memory=save.memory, treatment=treatment)

  ret <- lyg.main(fit.trial, fit.survey, fit2.survey, fit2.trial, 
                  x0, obj) 
  ret
}

lyg.main <- function(cox_t.d1, cox_s.d1, cox_s.d2, cox_t.d2, 
                     x0, obj) {

  treatment       <- obj$treatment
  nrow.samp.t     <- ifelse(is.null(cox_t.d1), 0, cox_t.d1$n)
  nrow.samp.s     <- cox_s.d1$n
  obj$nrow.samp.t <- nrow.samp.t
  obj$nrow.samp.s <- nrow.samp.s

  beta.est     <- getBetas(cox_t.d1, cox_s.d1, cox_s.d2, cox_t.d2, treatment=treatment) 
  beta_w       <- get_beta_w(cox_t.d1, cox_s.d1, cox_s.d2, cox_t.d2, beta.est,
                             nrow.samp.t, nrow.samp.s)
  t_star.s     <- getUnqEventTimesSurvey(cox_s.d1, cox_s.d2)
  obj          <- update_objects(obj, t_star.s)

  tmp          <- getEstFrom_beta_w(beta_w, "s1", nrow.samp.s)
  Lambda0.s1_w <- getCumBaselineHazard(cox_s.d1, tmp, t_star.s)
  tmp          <- getEstFrom_beta_w(beta_w, "s2", nrow.samp.s)
  Lambda0.s2_w <- getCumBaselineHazard(cox_s.d2, tmp, t_star.s)
  Lambda0      <- cbind(Lambda0.s1_w$Lambda, Lambda0.s2_w$Lambda)
  if (obj$calc.var) {
    Lambda0_w  <- array(c(Lambda0.s1_w$Lambda_wt, Lambda0.s2_w$Lambda_wt),
                        c(nrow.samp.s, length(t_star.s), 2))
  } else {
    Lambda0_w  <- NULL
  }
  rm(Lambda0.s1_w, Lambda0.s2_w, tmp); gc()

  # Get estimates and variances
  tmp <- lyg.getEstimates(obj, Lambda0, Lambda0_w, x0, t_star.s, 
                          beta.est, beta_w, cox_s.d1, cox_t.d1)
  rm(Lambda0, Lambda0_w); gc()
  lyg.setReturn(x0, tmp$estimate, tmp[["variance", exact=TRUE]])
}

lyg.setReturn <- function(x0, est, var) {
  rnms <- rownames(x0)
  if (!length(rnms)) rnms <- as.character(1:length(est))
  names(est) <- rnms
  if (length(var)) names(var) <- rnms
  
  list(estimate=est, variance=var)
}

lyg.getEstimates <- function(obj, Lambda0, Lambda0_w, x0, t_star.s, 
                             beta.est, beta_w, cox_s.d1, cox_t.d1) {

  if (!obj$save.memory) {
    ret <- lyg.getEstForAllx(obj, Lambda0, Lambda0_w, x0, t_star.s, 
                             beta.est, beta_w, cox_s.d1, cox_t.d1)
  } else {
    # Get unique covariate patterns
    xids  <- myPasteCols(x0, sep=":")
    uids  <- unique(xids)
    rows  <- match(xids, uids)
    tmp   <- !duplicated(xids)
    x     <- x0[tmp, , drop=FALSE] 
    nrx   <- nrow(x)
    rm(xids, uids, tmp)
    gc()

    est <- rep(NA, nrx)
    var <- est
 
    # Loop over each row of x
    for (i in 1:nrx) {
      tmp <- lyg.getEstForAllx(obj, Lambda0, Lambda0_w, x[i, , drop=FALSE],
                               t_star.s, beta.est, beta_w, cox_s.d1, cox_t.d1)
      est[i] <- tmp$estimate
      var[i] <- tmp$variance
    }

    # Get estimates for each row of x0
    ret <- list(estimate=est[rows], variance=var[rows])
  }
  ret
}

myPasteCols <- function(x, sep="*") {

  nc  <- ncol(x)
  ret <- x[, 1, drop=TRUE]
  if (nc > 1) {
    for (i in 2:nc) ret <- paste(ret, x[, i, drop=TRUE], sep=sep)
  }
  ret
}

lyg.getEstForAllx <- function(obj, Lambda0, Lambda0_w, x0, t_star.s, 
                             beta.est, beta_w, cox_s.d1, cox_t.d1) {

  S_Delta_mu   <- Delta_mu_inf(obj$nrow.samp.s, Lambda0=Lambda0, t=t_star.s, 
                               t1=obj$time.eff.end, x=x0, betas=beta.est, 
                               Lambda0_w=Lambda0_w, 
                               beta_w=beta_w, deviate=obj$calc.var)

  # Estimate of LYG
  Delta_mu_est <- colSums(S_Delta_mu$Delta_mu[t_star.s <= obj$time.cutoff, , drop=FALSE]) 
  S_Delta_mu$Delta_mu <- NULL; gc()

  # Variance of LYG
  Delta_mu_w   <- NULL
  Delta_mu_var <- NULL
  if (obj$calc.var) {
    Delta_mu_w   <- getRowSums.lyg(S_Delta_mu$Delta_mu_w, t_star.s, obj$time.cutoff)
    Delta_mu_var <- lyg.variance(Delta_mu_w, cox_s.d1, cox_t.d1, obj$nrow.samp.t)
  }
  rm(S_Delta_mu); gc()
  
  list(estimate=Delta_mu_est, variance=Delta_mu_var)
}

lyg.variance <- function(Delta_mu_w, cox_s.d1, cox_t.d1, nrow.samp.t) {

  x           <- as.data.frame(Delta_mu_w)
  ncx         <- ncol(x) 
  cx          <- paste0("x", 1:ncx)
  colnames(x) <- cx
  if (nrow.samp.t>0){
  	 vec         <- getWgtsFromFit(cox_s.d1) 
  	 tmp         <- getWgtsFromFit(cox_t.d1)
  	 x$wt        <- c(vec, tmp) 
  	 vec         <- getStrataFromFit(cox_s.d1) 
  	 tmp         <- getStrataFromFit(cox_t.d1)+max(vec)
  	 x$strata    <- c(vec, tmp)
  	 vec         <- getPsuFromFit(cox_s.d1) 
  	 tmp         <- getPsuFromFit(cox_t.d1) 
  	 x$PSU       <- c(vec, tmp)
  	 }else{
  	 x$wt        <- getWgtsFromFit(cox_s.d1) 
  	 x$strata    <- getStrataFromFit(cox_s.d1)
  	 x$PSU       <- getPsuFromFit(cox_s.d1)
  }
  tmp         <- svydesign(ids=~PSU, strata=~strata, weights=~wt, 
                           data=x, nest=TRUE)
  form        <- paste0(cx, collapse=" + ")
  form        <- as.formula(paste0("~ ", form))
  ret         <- diag(vcov(svytotal(form, design=tmp)))
  ret
}

getRowSums.lyg <- function(Delta_mu_w, t_star.s, t_tau) {

  d   <- dim(Delta_mu_w)
  ret <- matrix(data=NA, nrow=d[1], ncol=d[3])
  tmp <- t_star.s <= t_tau
  for (i in 1:d[3]) {
    ret[, i] <- rowSums(Delta_mu_w[, tmp, i])
  }
  ret
}

update_objects <- function(obj, t_star.s) {

  maxt <- max(t_star.s, na.rm=TRUE)
  tmp  <- obj[["time.eff.end", exact=TRUE]]
  if (is.null(tmp)) obj[["time.eff.end"]] <- maxt
  tmp  <- obj[["time.cutoff", exact=TRUE]]
  if (is.null(tmp)) obj[["time.cutoff"]] <- maxt
  obj
}

getTrtVarName <- function(nms) {

  ret <- "trt"
  while (1) {
    if (ret %in% nms) {
      ret <- paste0(".", ret)
    } else {
      break
    }
  }
  ret
}

getBetas <- function(cox_t.d1, cox_s.d1, cox_s.d2, cox_t.d2, treatment) {

  # If both treament and fit.trial are not NULL, then use fit.trial and
  #   give a warning.
  if (length(treatment) && (length(cox_t.d1) || length(cox_t.d2))) {
    warning("The cox model for treatment effect from the trial is used.")
    treatment <- NULL
  }

  coef1         <- cox_s.d1$coefficients
  coef2         <- cox_s.d2$coefficients
  nms1          <- names(coef1)
  nms2          <- names(coef2)
  nms           <- unique(c(nms1, nms2))
  len           <- length(nms)  
  ret           <- matrix(data=0, nrow=len, ncol=2)
  colnames(ret) <- c("event1", "event2")
  rownames(ret) <- nms
  ret[nms1, 1]  <- coef1
  ret[nms2, 2]  <- coef2
  if (length(treatment)) {
    cx            <- rownames(ret)
    ret           <- rbind(ret, treatment)
    rownames(ret) <- c(cx, getTrtVarName(cx))
  } else {
    if (length(cox_t.d1)) {
      td1 <- cox_t.d1$coefficients
    } else { 
      td1 <- 0
    }
    if (length(cox_t.d2)) {
      td2 <- cox_t.d2$coefficients
    } else { 
      td2 <- 0
    }
    cox_t <- c(td1, td2)
    cx    <- rownames(ret)
    ret   <- rbind(ret, cox_t)
    rownames(ret) <- c(cx, getTrtVarName(cx))
  }
  
  ret
}

get_beta_w <- function(cox_t.d1, cox_s.d1, cox_s.d2, cox_t.d2, beta.est,
                       nrow.samp.t, nrow.samp.s) {

  beta_w <- array(0, dim = c(nrow.samp.s+nrow.samp.t, nrow(beta.est), ncol(beta.est)),
                  dimnames = list(NULL, rownames(beta.est), colnames(beta.est)))

  tmp1 <- beta_wt.cox(surv.fit = cox_s.d1)$beta_wt
  colnames(tmp1) = names(cox_s.d1$coeff)
  tmp2 <- beta_wt.cox(surv.fit = cox_s.d2)$beta_wt
  colnames(tmp2) = names(cox_s.d2$coeff)  
  tmp1.idx = match(colnames(tmp1), rownames(beta.est))
  tmp2.idx = match(colnames(tmp2), rownames(beta.est))
  beta_w[1:nrow.samp.s,tmp1.idx,1] <- tmp1
  beta_w[1:nrow.samp.s,tmp2.idx,2] <- tmp2  
  if (nrow.samp.t!=0){
    tmp <- beta_wt.cox(surv.fit = cox_t.d1)
    beta_w[(1:nrow.samp.t+nrow.samp.s),nrow(beta.est),1]   <- tmp$beta_wt
    if (!is.null(cox_t.d2)) {
      tmp <- beta_wt.cox(surv.fit = cox_t.d2)
      beta_w[(1:nrow.samp.t+nrow.samp.s),nrow(beta.est),2] <- tmp$beta_wt
    }  	
  }  
  beta_w
}

getEstFrom_beta_w <- function(beta_w, which, nrow.samp.s) {

  if (which == "s1") {
    ret <- beta_w[1:nrow.samp.s,,1]
  } else if (which == "s2") {
    ret <- beta_w[1:nrow.samp.s,,2] 
  } else {
    stop("INTERNAL CODING ERROR")
  }
  ret
}

getUnqEventTimesSurvey <- function(cox_s.d1, cox_s.d2) {

  etimes1 <- lambda_w(cox_s.d1, only.event.times=TRUE)
  etimes2 <- lambda_w(cox_s.d2, only.event.times=TRUE)
  ret     <- sort(unique(c(etimes1, etimes2))) 
  ret
}

getCumBaselineHazard <- function(fitsurv, beta_wt, t_star.s) {

  beta_wt  <- beta_wt[,match(names(fitsurv$coeff), colnames(beta_wt))]
  lambda_w <- lambda_w(surv.fit=fitsurv, beta_wt=beta_wt)
  ret      <- Lambda_w(lambda_out=lambda_w, t_star.s)  
  ret
}

getWgtsFromFit <- function(fit) {

  ret <- NULL
  if ("svycoxph" %in% class(fit)) {
    x  <- fit$survey.design$variables
    nm <- names(fit$survey.design$allprob)
    if (nm %in% colnames(x)) ret <- unlist(x[, nm, drop=TRUE])
  } else {
    ret <- weights(fit)
  }
  if (!length(ret)) ret <- rep(1, fit$n)
  ret
}

getStrataFromFit <- function(fit) {

  ret <- NULL
  if ("svycoxph" %in% class(fit)) {
    x  <- fit$survey.design$variables
    nm <- names(fit$survey.design$strata)
    if (nm %in% colnames(x)) ret <- unlist(x[, nm, drop=TRUE])
  } else {
    ret <- NULL
  }
  if (!length(ret)) ret <- rep(1, fit$n)
  ret
}

getPsuFromFit <- function(fit) {

  ret <- NULL
  if ("svycoxph" %in% class(fit)) {
    x  <- fit$survey.design$variables
    nm <- names(fit$survey.design$cluster)
    if (nm %in% colnames(x)) ret <- unlist(x[, nm, drop=TRUE])
  } else {
    ret <- NULL
  }
  if (!length(ret)) ret <- 1:fit$n
  ret
}




