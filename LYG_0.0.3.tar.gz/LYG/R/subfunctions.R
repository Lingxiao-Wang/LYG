###################################################################################################################
#Derivative of U and beta (cox regression) w.r.t. the weight, used for variance calculation                       #
# INPUT:                                                                                                          #
# surv.fit  - output of coxph or      #
# dat     - a dataframe including variables of sample weight (wt), time (t), event status (d)                     #
# wt      - name of the sample weight variable                                                                    #
# OUTPUT:                                                                                                         #
# beta_wt       - influence functions for beta coefficients (derivative of beta w.r.t. the sample weights)        #
# Delta_beta.wt - sample weighted influence functions for beta coefficients                                       #
###################################################################################################################
beta_wt.cox = function(surv.fit){

  dat = eval(surv.fit$call$data)
  if(is.null(dat)){
    dat = eval(surv.fit$survey.design$variables)
    dat$wt = 1/surv.fit$survey.design$prob
  } else(dat$wt=1)  
  x.mtrx = model.matrix(surv.fit)
  rel_hzd = exp(x.mtrx%*%surv.fit$coefficients)
  fit.vars = all.vars(surv.fit$formula)
  t = fit.vars[1]; d = fit.vars[2]
  n = nrow(dat)
  p = ncol(x.mtrx)
  dat$id = 1:n
  dat$rel_hzd = rel_hzd
  dat$wt_e = dat$wt*dat$rel_hzd
  
  x.mtrx = as.matrix(x.mtrx[order(dat[,t]),])
  dat = dat[order(dat[,t]),]
  dat$H_dnom = rev(cumsum(rev(dat$wt_e)))# H2
  dat$H_num = as.matrix(cumsum(as.data.frame(c(dat$wt_e)*x.mtrx)[n:1,]))[n:1,] #H1
  
  ties = duplicated(dat[,t])
  if(sum(ties)>0){
    H_uniq = dat[!ties,c(t, "H_dnom", "H_num")]
    H_dat = H_uniq[rep(1:nrow(H_uniq), table(dat[,t])),]
    #h_dat[,t]==dat[,t]
    dat[, c("H_dnom", "H_num")] = H_dat[, c("H_dnom", "H_num")]
    
  }
  
  x.mtrx = as.matrix(x.mtrx[order(dat$id), ])
  dat = dat[order(dat$id), ]
  
  H = as.matrix(dat$H_num/dat$H_dnom)
  
  d_indx = which(dat[,d]==1)
  dat1 = dat[d_indx,]
  # create a two-column matrix sum_wt.t, with the first column being the unique event time, 
  # the second column being the sum of weights for individuals having the event time t
  if(sum(duplicated(dat1[, t]))>0){
    dat1$weight = dat1$wt
    
    dat1_tb <- data.table(dat1, key=t)
    names(dat1_tb)[ncol(dat1_tb)]="weight"
    names(dat1_tb)[names(dat1_tb)==t]="t_tb"
    #sum_wt.t <- as.data.frame(dat1_tb[, sum(weight), by=list(t_tb)])
    # Remove build warnings from above line
    weight   <- dat1_tb$weight
    sum_wt.t <- as.data.frame(dat1_tb[, sum(weight), by="t_tb"])


    #sum_wt.t = aggregate(dat1$wt*, by=list(rep(1, nrow(dat1)),dat1[,t]), sum)
    sum_wt.t = sum_wt.t[match(unique(dat1[, t]), sum_wt.t[,1]),]
    unq_t.d_indx = d_indx[!duplicated(dat1[, t])]
  }else{
    sum_wt.t=cbind(dat1[, t], dat1$wt)
    unq_t.d_indx = d_indx
  }
  
  U_w_2 = 0 # Ai 
  for(j in 1:nrow(sum_wt.t)){
    k=unq_t.d_indx[j]
    U_w_2.k = sum_wt.t[j, 2]*(c((dat[,t]>=dat[,t][k])*dat$rel_hzd)*x.mtrx/dat$H_dnom[k]-
                                outer(c((dat[,t]>=dat[,t][k])*dat$rel_hzd),as.numeric(as.matrix(dat$H_num)[k,]))/(dat$H_dnom[k])^2)
    U_w_2 = U_w_2.k+U_w_2
  }
  
  Ui_wt= as.matrix(dat[,d]*(x.mtrx- H)-U_w_2)
  
  U_beta_1 = 0
  for(j in 1:nrow(sum_wt.t)){
    k=unq_t.d_indx[j]
    sum_j = t(as.matrix(x.mtrx*c(dat$wt_e*as.numeric(dat[,t]>=dat[,t][k]))))%*%as.matrix(x.mtrx)
    U_beta_1 =-sum_wt.t[j, 2]*sum_j/dat$H_dnom[k]+U_beta_1
  }
  U_beta = U_beta_1 +t(c(dat$wt[d_indx])*H[d_indx,])%*%H[d_indx,]
  beta_wt = -Ui_wt%*%solve(U_beta)
  Delta_beta.wt = c(dat$wt)*beta_wt
  
  #print("beta_wt.cox OK")
  return(list(beta_wt = beta_wt,
              Delta_beta.wt = Delta_beta.wt)
  )
}
###################################################################################################
# lambda_w is the FUNCTION to estimate baseline hazards and their derivatives w.r.t. sample weight#
# INPUT                                                                                           #
#  surv.fit - an object of fitted Cox regression model (output of coxph or svycoxph)              #
#  beta_wt  - derivative of Cox regression coefficients w.r.t. sample weight if different         #
#             from the output of coxph or svycoxph. The default is NULL                           #
# OUPUT                                                                                           #
#  lambda    - a vector of estimates of  baseline hazards at sorted unique event times            #
#  lambda_wt - a matrix of derivative of baseline hazards w.r.t. sample weight                    #
#              at sorted unique event times                                                       #
#  u         - sorted unique event times                                                          #   
###################################################################################################
lambda_w = function(surv.fit, beta_wt=NULL, only.event.times=FALSE){
  var.names = all.vars(surv.fit$formula)
  t = var.names[1]
  d = var.names[2]
  dat = eval(surv.fit$call$data)
  if(is.null(dat)){
    dat = eval(surv.fit$survey.design$variables)
    dat$wt = 1/surv.fit$survey.design$prob
  } else(dat$wt=1)
  x.mtrx = model.matrix(surv.fit)
  rel_hzd = exp(x.mtrx%*%c(surv.fit$coefficients))
  dat$rel_hzd = rel_hzd
  n = nrow(dat)
  dat$id = 1:n
  
  Nt=NULL; Zt=NULL; Yt=NULL; t_unq = NULL
  #dat = dat[order(dat$t),]
  dat1 = dat[dat[,d]==1,]

  # For efficiency
  if (only.event.times) return(unique(dat1[,t]))

  lambda_dat = data.frame(t = unique(dat1[,t]))
  names(lambda_dat)=t
  dat$Yi_t = outer(dat[,t], lambda_dat[,], FUN=">=")
  colnames(dat$Yi_t)=paste("t=", lambda_dat[,t], sep="")
  row.names(dat$Yi_t) = row.names(dat)
  dat$Ii_t = outer(dat[,t], lambda_dat[,t], FUN="==")
  colnames(dat$Ii_t)=paste("t=", lambda_dat[,t], sep="")
  row.names(dat$Ii_t) = row.names(dat)
  
  for (i in 1:length(lambda_dat[,t])){
    Nt_i = sum((dat$wt*dat[,d])*dat$Ii_t[,i])
    Zt_i = sum((dat$wt*dat$rel_hzd)*dat$Yi_t[,i])
    t_unq = c(t_unq, lambda_dat[,t][i])
    Nt = c(Nt, Nt_i)
    Zt = c(Zt, Zt_i)
  }  
  
  lambda_dat$Nt = Nt
  lambda_dat$Zt = Zt
  lambda_dat$lambda = Nt/Zt
  if(is.null(beta_wt)) beta_wt = residuals(surv.fit, type="dfbeta")/dat$wt
  Nt_w = c(dat[,d])*dat$Ii_t
  Zt_w = c(dat$rel_hzd)*dat$Yi_t+beta_wt%*%t(t(c(dat$wt*dat$rel_hzd)*dat$Yi_t)%*%x.mtrx)
  lambda_wt = t((lambda_dat$Zt)^-1*(t(Nt_w)-lambda_dat$lambda*t(Zt_w)))
  colnames(lambda_wt) = lambda_dat[,t]
  return(list(lambda = lambda_dat$lambda,
              lambda_wt = lambda_wt,
              u = lambda_dat[,t])
  )
}
##########################################################################################
# Lambda_w is the FUNCTION to estimate cumulative baseline hazard at given time points   #
#                          and its derivative w.r.t. sample weight                       #
# INPUT                                                                                  #
#  lambda_out - an object of output of function lambda_w                                 #
#  t_star     - a vector of time points for cumulative baseline hazard inference         #
# OUPUT                                                                                  #
#  Lambda    - a vector of estimates of cumulative baseline hazards at given time pionts #
#  Lambda_wt - a matrix of derivative of cumulative baseline hazardS w.r.t. sample weight#
#              at given time points                                                      #
##########################################################################################
Lambda_w = function(lambda_out, t_star){
  u = lambda_out$u
  lambda_wt = lambda_out$lambda_wt[,order(u)]
  lambda    = lambda_out$lambda[order(u)]
  u = sort(u)
  t_diff = outer(u, t_star, FUN="-")
  t_diff[t_diff>0]=-10^6
  Lambda = cumsum(lambda)[apply(t_diff, 2, which.max)]
  Lambda_wt = cbind(NULL,rowCumsums(lambda_wt)[,apply(t_diff, 2, which.max)])
  colnames(Lambda_wt) = paste("Lambda(t=", t_star, ")", sep="")
  return(list(Lambda = Lambda,
              Lambda_wt = Lambda_wt))
}

########################################################################################################################################
# Delta_mu_inf is the main FUNCTION to estimate LYG                                                                                    #
# INPUT                                                                                                                                #
# Lambda0 - a two-column matrix of cumulative baseline hazard for the major event (1st column), and the competing event (2nd column),  #
# t       - time points                                                                                                                #
# t1      - the time point when the effect of intervention is assumed to disappear                                                     #
# x       - matrix of covariate values for m individuals of interest.                                                                  #
# betas   - a two-column matrix of the log-HRs for the major event (1st column), and the competing event (2nd column).                 #
#           it has the format of cbind(c(coefficients of other effects for event 1, coefficient of effect of intervention for event1), # 
#                                      c(coefficients of other effects for event 1, coefficient of effect of intervention for event1)) #
# Lambda0_w - influence functions of the cumulative baseline hazard for variance calculation. It is a ns*length(t)*2 array             #
# beta_w    - influence functions of betas for variance estimation. It is a (ns+nt)*(number of betas+1)*2 array                        #
# deviate   - T for calculating the influence function of Delta_mu. If deviate==F, Lambda0_w and beta_w should be NULL                 #
# OUTPUT                                                                                                                               #
# Delta_mu   - LYG at each time point for each individuals in x. It is a length(t)*(nrow(samp.t)+nrow(samp.s)) matrix                  #
# Delta_mu_w - an array of influence function of Delta_mu for variance calculation.                                                    #
########################################################################################################################################
# INPUT
# cox models for primary event, other cause of death
# cox models for intervention effect on primary, and other cause of death
# time point when the effect of intervention disappear
# time point the LYG stops
# calculate the variance or not

Delta_mu_inf = function(n_s, Lambda0, t, t1, x, betas, Lambda0_w = NULL, beta_w=NULL, deviate=F){
  #n_s = nrow(Lambda0_w)
  n = nrow(beta_w)
  n_t=n-n_s
  n_beta = nrow(betas)
  x = matrix(x, ncol=n_beta-1)
  n_x = nrow(x)
  K = ncol(betas)
  t1.indx = which.min(abs(t-t1))
  t1=t[t1.indx]
  t.l.indx = which(t<=t1);  t.h.indx = which(t>t1)
  Lambda.inf_in = function(y, deviate){

    rr = exp(cbind(x, y)%*%betas)
    rr_y0 = exp(x%*%betas[-n_beta,])
    rr_y = exp(outer(y,betas[n_beta,]))
    Lambda=0;Lambda_w=0
    for(k in 1:K){
      if((betas[n_beta,k]==0)|(y==0)){
        Lambda.k = outer(rr[,k], Lambda0[,k])
        if(deviate){
          Lambda_w.k=array(0,c(n, length(t), nrow(x)))
          outer.row1 = function(i) outer(c(beta_w[1:n_s,-n_beta,k]%*%c(x[i,])), rr[i,k]*Lambda0[,k])
          Lambda_w.k[1:n_s,,] = outer(Lambda0_w[,,k], rr[,k])+
            array(sapply(1:nrow(x), FUN=outer.row1), c(n_s,length(t),n_x))
          Lambda_w = Lambda_w+Lambda_w.k
        }
      }else{
        Lambda.k = outer(rr[,k], Lambda0[t.l.indx,k])
        Lambda.k = cbind(Lambda.k, outer(rr_y0[,k], Lambda0[t.h.indx,k])+Lambda0[t1.indx,k]*rr_y0[,k]*(rr_y[,k]-1))
        if(deviate){
          Lambda_w.k=array(0,c(n, length(t), nrow(x)))
          outer.row = function(rr,t.indx,i) outer(c(beta_w[1:n_s,-n_beta,k]%*%c(x[i,])), rr[i,k]*Lambda0[t.indx,k])
          Lambda_w.k[1:n_s,1:length(t.l.indx),]= outer(Lambda0_w[,t.l.indx,k], rr[,k])+
            array(sapply(1:nrow(x), FUN=outer.row, t.indx=t.l.indx, rr=rr), 
                  c(n_s,length(t.l.indx),n_x))
          Lambda_w.k[1:n_t+n_s,1:length(t.l.indx),] = outer(outer(beta_w[1:n_t+n_s,n_beta,k], Lambda0[t.l.indx,k]), rr[,k])
          if(length(t.l.indx)<length(t)){
            Lambda_w.k.h.t1 = outer(Lambda0_w[,t1.indx,k], (rr_y[,k]-1)*rr_y0[,k])+
              Lambda0[t1.indx,k]*(rr_y[,k]-1)*(beta_w[1:n_s,-n_beta,k]%*%t(rr_y0[,k]*x))
            Lambda_w.k.h.t1 = array(Lambda_w.k.h.t1, c(n_s, nrow(x),1))
            Lambda_w.k.h.t1 = aperm(array(Lambda_w.k.h.t1[,,rep(1, length(t.h.indx))], c(n_s, n_x, length(t.h.indx))), 
                                    c(1,3,2))
            Lambda_w.k.h.tj = outer(Lambda0_w[,t.h.indx,k], rr_y0[,k])+
              array(sapply(1:nrow(x), FUN=outer.row, t.indx=t.h.indx, rr=rr_y0), 
                    c(n_s,length(t.h.indx),n_x))
            Lambda_w.k[1:n_s,1:length(t.h.indx)+length(t.l.indx),] = Lambda_w.k.h.t1+Lambda_w.k.h.tj
            Lambda_w.k[1:n_t+n_s,1:length(t.h.indx)+length(t.l.indx),] = 
              aperm(array(array(Lambda0[t1.indx,k]*rr_y[,k]*outer(beta_w[1:n_t+n_s,n_beta,k], rr_y0[,k]), 
                                c(n_t,n_x,1))[,,rep(1,length(t.h.indx))], c(n_t,n_x,length(t.h.indx))), 
                    c(1, 3, 2))
          }
          Lambda_w = Lambda_w+Lambda_w.k
        }
      } 
      Lambda = Lambda+t(Lambda.k)
      #print(k)
    }
    return(list(Lambda = Lambda, Lambda_w = Lambda_w))
  }
  Lambda_out1=Lambda.inf_in(y=1, deviate=deviate)
  Lambda_out0=Lambda.inf_in(y=0, deviate=deviate)
  S1 = exp(-Lambda_out1$Lambda)
  S0 = exp(-Lambda_out0$Lambda)
  if(deviate){
    t_diff = t-c(0, t[-length(t)])
    S1_w = -array(array(S1,c(1,length(t),n_x))[rep(1,n),,], c(n,length(t),n_x))*Lambda_out1$Lambda_w
    S0_w = -array(array(S0,c(1,length(t),n_x))[rep(1,n),,], c(n,length(t),n_x))*Lambda_out0$Lambda_w
    return(list(Delta_mu = t_diff*(S1-S0),
                Delta_mu_w = array(array(t_diff,c(1,length(t),n_x))[rep(1,n),,], c(n,length(t),n_x))*(S1_w-S0_w)
                ))
  }else{
    t_diff = t-c(0, t[-length(t)])
    return(list(Delta_mu = t_diff*(S1-S0),
                Delta_mu_w = NULL))
  }
}

Delta_mu_inf.orig = function(Lambda0, t, t1, x, betas, Lambda0_w = NULL, beta_w=NULL, deviate=F){
  n_s = nrow(Lambda0_w)
  n = nrow(beta_w)
  n_t=n-n_s
  n_beta = nrow(betas)
  x = matrix(x, ncol=n_beta-1)
  n_x = nrow(x)
  K = ncol(betas)
  t1.indx = which.min(abs(t-t1))
  t1=t[t1.indx]
  t.l.indx = which(t<=t1);  t.h.indx = which(t>t1)
  Lambda.inf_in = function(y, deviate){

    rr = exp(cbind(x, y)%*%betas)
    rr_y0 = exp(x%*%betas[-n_beta,])
    rr_y = exp(outer(y,betas[n_beta,]))
    Lambda=0;Lambda_w=0
    for(k in 1:K){
      if((betas[n_beta,k]==0)|(y==0)){
        Lambda.k = outer(rr[,k], Lambda0[,k])
        if(deviate){
          Lambda_w.k=array(0,c(n, length(t), nrow(x)))
          outer.row1 = function(i) outer(c(beta_w[1:n_s,-n_beta,k]%*%c(x[i,])), rr[i,k]*Lambda0[,k])
          Lambda_w.k[1:n_s,,] = outer(Lambda0_w[,,k], rr[,k])+
            array(sapply(1:nrow(x), FUN=outer.row1), c(n_s,length(t),n_x))
          Lambda_w = Lambda_w+Lambda_w.k
        }
      }else{
        Lambda.k = outer(rr[,k], Lambda0[t.l.indx,k])
        Lambda.k = cbind(Lambda.k, outer(rr_y0[,k], Lambda0[t.h.indx,k])+Lambda0[t1.indx,k]*rr_y0[,k]*(rr_y[,k]-1))
        if(deviate){
          Lambda_w.k=array(0,c(n, length(t), nrow(x)))
          outer.row = function(rr,t.indx,i) outer(c(beta_w[1:n_s,-n_beta,k]%*%c(x[i,])), rr[i,k]*Lambda0[t.indx,k])
          Lambda_w.k[1:n_s,1:length(t.l.indx),]= outer(Lambda0_w[,t.l.indx,k], rr[,k])+
            array(sapply(1:nrow(x), FUN=outer.row, t.indx=t.l.indx, rr=rr), 
                  c(n_s,length(t.l.indx),n_x))
          Lambda_w.k[1:n_t+n_s,1:length(t.l.indx),] = outer(outer(beta_w[1:n_t+n_s,n_beta,k], Lambda0[t.l.indx,k]), rr[,k])
          if(length(t.l.indx)<length(t)){
            Lambda_w.k.h.t1 = outer(Lambda0_w[,t1.indx,k], (rr_y[,k]-1)*rr_y0[,k])+
              Lambda0[t1.indx,k]*(rr_y[,k]-1)*(beta_w[1:n_s,-n_beta,k]%*%t(rr_y0[,k]*x))
            Lambda_w.k.h.t1 = array(Lambda_w.k.h.t1, c(n_s, nrow(x),1))
            Lambda_w.k.h.t1 = aperm(array(Lambda_w.k.h.t1[,,rep(1, length(t.h.indx))], c(n_s, n_x, length(t.h.indx))), 
                                    c(1,3,2))
            Lambda_w.k.h.tj = outer(Lambda0_w[,t.h.indx,k], rr_y0[,k])+
              array(sapply(1:nrow(x), FUN=outer.row, t.indx=t.h.indx, rr=rr_y0), 
                    c(n_s,length(t.h.indx),n_x))
            Lambda_w.k[1:n_s,1:length(t.h.indx)+length(t.l.indx),] = Lambda_w.k.h.t1+Lambda_w.k.h.tj
            Lambda_w.k[1:n_t+n_s,1:length(t.h.indx)+length(t.l.indx),] = 
              aperm(array(array(Lambda0[t1.indx,k]*rr_y[,k]*outer(beta_w[1:n_t+n_s,n_beta,k], rr_y0[,k]), 
                                c(n_t,n_x,1))[,,rep(1,length(t.h.indx))], c(n_t,n_x,length(t.h.indx))), 
                    c(1, 3, 2))
          }
          Lambda_w = Lambda_w+Lambda_w.k
        }
      } 
      Lambda = Lambda+t(Lambda.k)
      #print(k)
    }
    return(list(Lambda = Lambda, Lambda_w = Lambda_w))
  }
  Lambda_out1=Lambda.inf_in(y=1, deviate=deviate)
  Lambda_out0=Lambda.inf_in(y=0, deviate=deviate)
  S1 = exp(-Lambda_out1$Lambda)
  S0 = exp(-Lambda_out0$Lambda)
  if(deviate){
    t_diff = t-c(0, t[-length(t)])
    S1_w = -array(array(S1,c(1,length(t),n_x))[rep(1,n),,], c(n,length(t),n_x))*Lambda_out1$Lambda_w
    S0_w = -array(array(S0,c(1,length(t),n_x))[rep(1,n),,], c(n,length(t),n_x))*Lambda_out0$Lambda_w
    return(list(Delta_mu = t_diff*(S1-S0),
                Delta_mu_w = array(array(t_diff,c(1,length(t),n_x))[rep(1,n),,], c(n,length(t),n_x))*(S1_w-S0_w)
                ))
  }else{
    t_diff = t-c(0, t[-length(t)])
    return(list(Delta_mu = t_diff*(S1-S0),
                Delta_mu_w = NULL))
  }
}
