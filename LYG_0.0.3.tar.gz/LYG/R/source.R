lyg <- function(fit.survey, fit2.survey, fit.trial, fit2.trial=NULL,
                time.eff.end=NULL, time.cutoff=NULL,
                x0=NULL, calc.var=TRUE, save.memory=FALSE) {

  # Check for errors
  check_fit(fit.trial, "fit.trial")
  check_fit(fit.survey, "fit.survey")
  check_fit(fit2.survey, "fit2.survey")
  if (length(fit2.trial)) check_fit(fit2.trial, "fit2.trial")
  check_fits.survey(fit.survey, fit2.survey)
  check_fits.trial(fit.trial, fit2.trial)
  check_num(time.eff.end, "time.eff.end")
  check_num(time.cutoff, "time.cutoff")
  check_log(calc.var, "calc.var")
  x0  <- check_x0(x0, fit.survey)
  obj <- list(time.eff.end=time.eff.end, time.cutoff=time.cutoff,
              calc.var=calc.var, save.memory=save.memory)

  ret <- lyg.main(cox_t.d1 = fit.trial, cox_s.d1 = fit.survey, cox_s.d2 = fit2.survey, cox_t.d2 = fit2.trial, x0, obj) 
  ret
}

lyg.main <- function(cox_t.d1, cox_s.d1, cox_s.d2, cox_t.d2, 
                     x0, obj) {

  nrow.samp.t     <- cox_t.d1$n
  nrow.samp.s     <- cox_s.d1$n
  obj$nrow.samp.t <- nrow.samp.t
  obj$nrow.samp.s <- nrow.samp.s

  beta.est     <- getBetas(cox_t.d1, cox_s.d1, cox_s.d2, cox_t.d2) 
  beta_w       <- get_beta_w(cox_t.d1, cox_s.d1, cox_s.d2, cox_t.d2, beta.est,
                             nrow.samp.t, nrow.samp.s)
  t_star.s     <- getUnqEventTimesSurvey(cox_s.d1, cox_s.d2)
  obj          <- update_objects(obj, t_star.s)

  tmp          <- getEstFrom_beta_w(beta_w, "s1", beta.est, nrow.samp.s)
  Lambda0.s1_w <- getCumBaselineHazard(cox_s.d1, tmp, t_star.s)
  tmp          <- getEstFrom_beta_w(beta_w, "s2", beta.est, nrow.samp.s)
  Lambda0.s2_w <- getCumBaselineHazard(cox_s.d2, tmp, t_star.s)
  Lambda0      <- cbind(Lambda0.s1_w$Lambda, Lambda0.s2_w$Lambda)
  if (obj$calc.var) {
    Lambda0_w  <- array(c(Lambda0.s1_w$Lambda_wt, Lambda0.s2_w$Lambda_wt),
                        c(nrow.samp.s, length(t_star.s), 2))
  } else {
    Lambda0_w  <- NULL
  }
  rm(Lambda0.s1_w, Lambda0.s2_w, tmp); gc()

  # Get estimates and variances
  tmp <- lyg.getEstimates(obj, Lambda0, Lambda0_w, x0, t_star.s, 
                          beta.est, beta_w, cox_s.d1, cox_t.d1)
  rm(Lambda0, Lambda0_w); gc()

  lyg.setReturn(x0, tmp$estimate, tmp[["variance", exact=TRUE]])
}

lyg.setReturn <- function(x0, est, var) {

  rnms <- rownames(x0)
  if (!length(rnms)) rnms <- as.character(1:length(est))
  names(est) <- rnms
  if (length(var)) names(var) <- rnms
  
  list(estimate=est, variance=var)
}

lyg.getEstimates <- function(obj, Lambda0, Lambda0_w, x0, t_star.s, 
                             beta.est, beta_w, cox_s.d1, cox_t.d1) {

  if (!obj$save.memory) {
    ret <- lyg.getEstForAllx(obj, Lambda0, Lambda0_w, x0, t_star.s, 
                             beta.est, beta_w, cox_s.d1, cox_t.d1)
  } else {
    # Get unique covariate patterns
    xids  <- myPasteCols(x0, sep=":")
    uids  <- unique(xids)
    rows  <- match(xids, uids)
    tmp   <- !duplicated(xids)
    x     <- x0[tmp, , drop=FALSE] 
    nrx   <- nrow(x)
    rm(xids, uids, tmp)
    gc()

    est <- rep(NA, nrx)
    var <- est
 
    # Loop over each row of x
    for (i in 1:nrx) {
      tmp <- lyg.getEstForAllx(obj, Lambda0, Lambda0_w, x[i, , drop=FALSE],
                               t_star.s, beta.est, beta_w, cox_s.d1, cox_t.d1)
      est[i] <- tmp$estimate
      var[i] <- tmp$variance
    }

    # Get estimates for each row of x0
    ret <- list(estimate=est[rows], variance=var[rows])
  }
  ret
}

myPasteCols <- function(x, sep="*") {

  nc  <- ncol(x)
  ret <- x[, 1, drop=TRUE]
  if (nc > 1) {
    for (i in 2:nc) ret <- paste(ret, x[, i, drop=TRUE], sep=sep)
  }
  ret
}

lyg.getEstForAllx <- function(obj, Lambda0, Lambda0_w, x0, t_star.s, 
                             beta.est, beta_w, cox_s.d1, cox_t.d1) {

  S_Delta_mu   <- Delta_mu_inf(obj$nrow.samp.s, Lambda0=Lambda0, t=t_star.s, 
                               t1=obj$time.eff.end, x=x0, betas=beta.est, 
                               Lambda0_w=Lambda0_w, 
                               beta_w=beta_w, deviate=obj$calc.var)

  # Estimate of LYG
  Delta_mu_est <- colSums(S_Delta_mu$Delta_mu[t_star.s <= obj$time.cutoff, , drop=FALSE]) 
  S_Delta_mu$Delta_mu <- NULL; gc()

  # Variance of LYG
  Delta_mu_w   <- NULL
  Delta_mu_var <- NULL
  if (obj$calc.var) {
    Delta_mu_w   <- getRowSums.lyg(S_Delta_mu$Delta_mu_w, t_star.s, obj$time.cutoff)
    Delta_mu_var <- lyg.variance(Delta_mu_w, cox_s.d1, cox_t.d1, obj$nrow.samp.t)
  }
  rm(S_Delta_mu); gc()
  
  list(estimate=Delta_mu_est, variance=Delta_mu_var)
}

lyg.variance <- function(Delta_mu_w, cox_s.d1, cox_t.d1, nrow.samp.t) {

  x           <- as.data.frame(Delta_mu_w)
  ncx         <- ncol(x) 
  cx          <- paste0("x", 1:ncx)
  colnames(x) <- cx
  vec         <- getWgtsFromFit(cox_s.d1) 
  tmp         <- getWgtsFromFit(cox_t.d1)
  x$wt        <- c(vec, tmp) 
  vec         <- getStrataFromFit(cox_s.d1) 
  tmp         <- getStrataFromFit(cox_t.d1)+max(vec)
  x$strata    <- c(vec, tmp)
  vec         <- getPsuFromFit(cox_s.d1) 
  tmp         <- getPsuFromFit(cox_t.d1) 
  x$PSU       <- c(vec, tmp)

  tmp         <- svydesign(ids=~PSU, strata=~strata, weights=~wt, 
                           data=x, nest=TRUE)
  form        <- paste0(cx, collapse=" + ")
  form        <- as.formula(paste0("~ ", form))
  ret         <- diag(vcov(svytotal(form, design=tmp)))
  ret
}

getRowSums.lyg <- function(Delta_mu_w, t_star.s, t_tau) {

  d   <- dim(Delta_mu_w)
  ret <- matrix(data=NA, nrow=d[1], ncol=d[3])
  tmp <- t_star.s <= t_tau
  for (i in 1:d[3]) {
    ret[, i] <- rowSums(Delta_mu_w[, tmp, i])
  }
  ret
}

update_objects <- function(obj, t_star.s) {

  maxt <- max(t_star.s, na.rm=TRUE)
  tmp  <- obj[["time.eff.end", exact=TRUE]]
  if (is.null(tmp)) obj[["time.eff.end"]] <- maxt
  tmp  <- obj[["time.cutoff", exact=TRUE]]
  if (is.null(tmp)) obj[["time.cutoff"]] <- maxt
  obj
}

getBetas <- function(cox_t.d1, cox_s.d1, cox_s.d2, cox_t.d2) {

  sd1 <- cox_s.d1$coefficients
  td1 <- cox_t.d1$coefficients
  sd2 <- cox_s.d2$coefficients
  if (length(cox_t.d2)) {
    td2 <- cox_t.d2$coefficients 
  } else {
    td2 <- rep(0, length(td1))
  }
  ret <- cbind(c(sd1, td1), c(sd2, td2))
  ret
}

get_beta_w <- function(cox_t.d1, cox_s.d1, cox_s.d2, cox_t.d2, beta.est,
                       nrow.samp.t, nrow.samp.s) {

  beta_w <- array(0, c(nrow.samp.s+nrow.samp.t, nrow(beta.est), ncol(beta.est)))

  tmp <- beta_wt.cox(surv.fit = cox_s.d1)
  beta_w[1:nrow.samp.s,1:(nrow(beta.est)-1),1]           <- tmp$beta_wt
  tmp <- beta_wt.cox(surv.fit = cox_s.d2)
  beta_w[1:nrow.samp.s,1:(nrow(beta.est)-1),2]           <- tmp$beta_wt
  tmp <- beta_wt.cox(surv.fit = cox_t.d1)
  beta_w[(1:nrow.samp.t+nrow.samp.s),nrow(beta.est),1]   <- tmp$beta_wt
  if (length(cox_t.d2)) {
    tmp <- beta_wt.cox(surv.fit = cox_t.d2)
    beta_w[(1:nrow.samp.t+nrow.samp.s),nrow(beta.est),2] <- tmp$beta_wt
  }

  beta_w
}

getEstFrom_beta_w <- function(beta_w, which, beta.est, nrow.samp.s) {

  if (which == "s1") {
    ret <- beta_w[1:nrow.samp.s,1:(nrow(beta.est)-1),1]
  } else if (which == "s2") {
    ret <- beta_w[1:nrow.samp.s,1:(nrow(beta.est)-1),2] 
  } else {
    stop("INTERNAL CODING ERROR")
  }
  ret
}

getUnqEventTimesSurvey <- function(cox_s.d1, cox_s.d2) {

  etimes1 <- lambda_w(cox_s.d1, only.event.times=TRUE)
  etimes2 <- lambda_w(cox_s.d2, only.event.times=TRUE)
  ret     <- sort(unique(c(etimes1, etimes2))) 
  ret
}

getCumBaselineHazard <- function(fitsurv, beta_wt, t_star.s) {

  lambda_w <- lambda_w(surv.fit=fitsurv, beta_wt=beta_wt)
  ret      <- Lambda_w(lambda_out=lambda_w, t_star.s)  
  ret
}

getWgtsFromFit <- function(fit) {

  ret <- NULL
  if ("svycoxph" %in% class(fit)) {
    x  <- fit$survey.design$variables
    nm <- names(fit$survey.design$allprob)
    if (nm %in% colnames(x)) ret <- unlist(x[, nm, drop=TRUE])
  } else {
    ret <- weights(fit)
  }
  if (!length(ret)) ret <- rep(1, fit$n)
  ret
}

getStrataFromFit <- function(fit) {

  ret <- NULL
  if ("svycoxph" %in% class(fit)) {
    x  <- fit$survey.design$variables
    nm <- names(fit$survey.design$strata)
    if (nm %in% colnames(x)) ret <- unlist(x[, nm, drop=TRUE])
  } else {
    ret <- NULL
  }
  if (!length(ret)) ret <- rep(1, fit$n)
  ret
}

getPsuFromFit <- function(fit) {

  ret <- NULL
  if ("svycoxph" %in% class(fit)) {
    x  <- fit$survey.design$variables
    nm <- names(fit$survey.design$cluster)
    if (nm %in% colnames(x)) ret <- unlist(x[, nm, drop=TRUE])
  } else {
    ret <- NULL
  }
  if (!length(ret)) ret <- 1:fit$n
  ret
}




