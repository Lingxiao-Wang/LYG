check_fit <- function(x, name, which=0) {

  if (!which) {
    cls <- c("svycoxph", "coxph")
  } else if (which == 1) {
    cls <- "svycoxph"
  } else {
    cls <- "coxph"
  }
  clsx <- class(x)
  tmp  <- clsx %in% cls
  if (!any(tmp)) {
    str <- paste0("'", cls, "'")
    str <- paste0(str, collapse=" or ")
    msg <- paste0("ERROR: ", name, " must have class ", str)
    stop(msg)
  }
  # Check coefficents
  coef <- x[["coefficients", exact=TRUE]]
  if (!length(coef)) {
    stop(paste0("ERROR: coefficients not found in ", name))
  }
  if (any(!is.finite(coef))) {
    stop(paste0("ERROR: non-finite coefficients found in ", name))
  }

  # For coxph object, check that the data still exists in evironment
  if (!("svycoxph" %in% clsx)) {
    dat <- x$call$data
    if (is.null(dat)) {
      msg <- paste0("ERROR: for the coxph object '", name,
                    "', a data frame to fit the model must exist in memory.")
      stop(msg) 
    }
    dat <- as.character(dat)
    if (!exists(dat)) {
      msg <- paste0("ERROR: for the coxph object '", name, "', the data '",
                    dat, "' must still exist in memory.")
      stop(msg) 
    }
  }

  NULL
}

check_num <- function(x, name, len=0, pos=1) {

  xlen <- length(x)
  if (!len && !xlen) return(NULL)
  if (len && (xlen != len)) {
    stop(paste0("ERROR: ", name, " must be a numeric value"))
  }
  if (!is.finite(x)) stop(paste0("ERROR: ", name, " must be a numeric value"))
  if (pos && (x <= 0)) {
    stop(paste0("ERROR: ", name, " must be a positive value"))
  }
  NULL
}

check_log <- function(x, name) {

  if (length(x) != 1) stop(paste0("ERROR: ", name, " must be TRUE or FALSE"))
  tmp <- x %in% c(TRUE, FALSE)
  if (!tmp) stop(paste0("ERROR: ", name, " must be TRUE or FALSE"))
  NULL
}

check_x0 <- function(x0, fit, name="x0") {

  if (!length(x0)) x0 <- model.matrix(fit) 
  if (!is.matrix(x0) && !is.data.frame(x0)) {
    stop(paste0("ERROR: ", name, " must be a matrix or data frame"))
  }
  coef <- fit$coefficients
  vars <- names(coef)
  tmp  <- !(vars %in% colnames(x0))
  if (any(tmp)) {
    miss <- paste0("'", vars[tmp], "'")
    miss <- paste0(miss, collapse=", ")
    msg  <- paste0("ERROR: ", name, " is missing columns ", miss)
    stop(msg)
  }
  x0 <- x0[, vars, drop=FALSE]
  x0 <- try(as.matrix(x0), silent=FALSE)
  if ("try-error" %in% class(x0)) {
    stop(paste0("ERROR: ", name, " cannot be coerced to a matrix"))
  }

  x0
}

check_fits.survey <- function(fit1, fit2) {

  nm1   <- "coxfit.survey"
  nm2   <- "coxfit2.survey"
  vars1 <- names(fit1$coeff)
  vars2 <- names(fit2$coeff)
  flag  <- all.equal(vars1, vars2)
  if (!is.logical(flag)) flag <- FALSE
  if (!flag) {
    msg <- paste0("ERROR: coefficients differ in ", nm1, " and ", nm2)
    stop(msg)
  }
  NULL
}

check_fits.trial <- function(fit1, fit2) {

  if (!length(fit2)) return(NULL)

  nm1   <- "coxfit.trial"
  nm2   <- "coxfit2.trial"
  vars1 <- names(fit1$coeff)
  vars2 <- names(fit2$coeff)
  flag  <- all.equal(vars1, vars2)
  if (!is.logical(flag)) flag <- FALSE
  if (!flag) {
    msg <- paste0("ERROR: coefficients differ in ", nm1, " and ", nm2)
    stop(msg)
  }
  NULL
}

